namespace QuotingDojo.Models
    {
        public class Quote 
            {
                public string name {get; set;}
                public string quote {get; set;}
            }
    }